package com.practice;

public class ShortestSubstringClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String value = "bcaacbc";
		int substringLength = shortestSubstring(value);
		System.out.println("Length of shortest substring is "+substringLength);
	}

	private static int shortestSubstring(String value) {
		// TODO Auto-generated method stub
		int length = value.length();
		int distinctChar = distinctCharacter(value,length);
		int result = length;
		for (int i = 0; i < length; i++) { 
            for (int j = 0; j < length; j++) { 
                  
                String subs = null; 
                if(i<j) 
                    subs = value.substring(i, j); 
                else
                    subs = value.substring(j, i); 
                int subs_lenght = subs.length(); 
                int sub_distinct_char = distinctCharacter(subs, subs_lenght);  
                if (subs_lenght < result && distinctChar == sub_distinct_char) { 
                    result = subs_lenght; 
                } 
            } 
        } 
        return result; 
	}

	private static int distinctCharacter(String value, int length) {
		// TODO Auto-generated method stub
		final int NO_OF_CHARS = 256;
		int count[] = new int[NO_OF_CHARS]; 
		  
        // Increase the count in array if a character 
        // is found 
        for (int i = 0; i < length; i++) { 
            count[value.charAt(i)]++; 
        } 
  
        int maximumdistinct = 0; 
        for (int i = 0; i < NO_OF_CHARS; i++) { 
            if (count[i] != 0) { 
                maximumdistinct++; 
            } 
        } 
  
        return maximumdistinct;
	}

}
