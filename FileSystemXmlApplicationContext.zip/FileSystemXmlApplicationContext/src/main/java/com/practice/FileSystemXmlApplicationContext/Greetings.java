package com.practice.FileSystemXmlApplicationContext;

public class Greetings {
    public void sayGreetings(){
        System.out.println("Hi, Welcome!");
    }
}