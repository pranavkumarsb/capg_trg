package com.practice.FileSystemXmlApplicationContext;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AbstractApplicationContext context = new FileSystemXmlApplicationContext("E:\\Softwares\\Projects\\beans.xml");
		Greetings welcome = (Greetings) context.getBean("welcome");
		welcome.sayGreetings();
		context.close();
		
	}

}
