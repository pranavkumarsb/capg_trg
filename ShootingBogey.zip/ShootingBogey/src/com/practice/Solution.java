package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of input(s):");
		int inputCount = Integer.parseInt(br.readLine().trim());
		System.out.println("Enter the starting position(s):");
		int[] startingPos = new int[inputCount];
		int[] speed = new int[inputCount];
		for(int i=0;i<inputCount;i++)
		{
			startingPos[i] = Integer.parseInt(br.readLine().trim());
		}
		System.out.println("Enter the speed for Bogeys:");
		for(int i=0;i<inputCount;i++)
		{
			speed[i] = Integer.parseInt(br.readLine().trim());
		}
		System.out.println("Maximum time Alex can protect the base: "+protectionTime(startingPos, speed));
	}

	private static int protectionTime(int[] startingPos, int[] speed) {
		// TODO Auto-generated method stub
		int time = 0;
		int[] intermediate = startingPos;
		boolean loop = true;
		while(loop)
		{
			boolean hasValue = false;
			for(int i=0;i<startingPos.length;i++)
			{
				intermediate[i] = startingPos[i] - speed[i];
			}
			for(int i=0;i<intermediate.length;i++)
			{
				if(intermediate[i]>0)
				{
					hasValue=true;
					break;
				}
			}
			if(hasValue)
			{
				loop=true;
			}
			else
			{
				loop=false;
			}
			time++;
		}
		return time;
	}
}
