package com.practice;

public class Acquaintance{
	
	String name;

	public Acquaintance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Acquaintance(String name) {
		super();
		this.name = name;
	}

	public void getStatus(String name)
	{
		System.out.println("["+name+"]"+" is just an acquaintance");
	}
}
