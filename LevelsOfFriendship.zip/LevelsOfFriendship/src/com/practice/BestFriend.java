package com.practice;

public class BestFriend extends Friend{
	
	String name,homeTown,favouriteSong;
	
	public BestFriend() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BestFriend(String name, String homeTown, String favouriteSong) {
		super();
		this.name = name;
		this.homeTown = homeTown;
		this.favouriteSong = favouriteSong;
	}
	
	public void getStatus(String name, String homeTown, String favouriteSong)
	{
		System.out.println("["+name+"] is my best friend. He is from ["+homeTown+"] and his favorite song is ["+favouriteSong+"]");
	}
}