package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Solution {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter nummber of inputs:");
		int inputCount = Integer.parseInt(br.readLine().trim());
		List<String> aList = new ArrayList<>();
		System.out.println("Enter the inputs:");
		for(int i=0;i<inputCount;i++)
		{
			aList.add(br.readLine().trim());
		}
		/*
		 * for(String s : aList) { System.out.println(s); }
		 */
		for(int i=0;i<inputCount;i++)
		{
			String[] type = aList.get(i).split(" ");
			//System.out.println(type[0]);
			switch(type[0]) {
			case "Acquaintance":
				Acquaintance acquaintance = new Acquaintance();
				acquaintance.getStatus(type[1]);
				break;
			case "Friend":
				Friend friend = new Friend();
				friend.getStatus(type[1],type[2]);
				break;
			case "BestFriend":
				BestFriend bestFriend = new BestFriend();
				bestFriend.getStatus(type[1],type[2],type[3]);
				break;
			}
		}
	}

}
