 package com.practice;

public class Relationship {

	public void getStatus(String name)
	{
		System.out.println("["+name+"]"+" is just an acquaintance");
	}
	
	public void getStatus(String name, String homeTown)
	{
		System.out.println("["+name+"]"+" is a friend and he is from "+"["+homeTown+"]");
	}
	
	public void getStatus(String name, String homeTown, String favouriteSong)
	{
		System.out.println("["+name+"] is my best friend. He is from ["+homeTown+"] and his favorite song is ["+favouriteSong+"]");
	}
}
