package com.practice;

public class Friend extends Acquaintance{

	String name;
	String homeTown;

	public Friend() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Friend(String name, String homeTown) {
		super();
		this.name = name;
		this.homeTown = homeTown;
	}
	
	public void getStatus(String name, String homeTown)
	{
		System.out.println("["+name+"]"+" is a friend and he is from "+"["+homeTown+"]");
	}
}