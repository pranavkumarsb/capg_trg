package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the string:");
		String string = br.readLine();
		//string = string.toLowerCase();
		Boolean test = findMissingLetters(string.toLowerCase());
		if(test==true)
			System.out.println("\""+string+"\""+" is a panagram");
		else
			System.out.println("\""+string+"\""+" is not a panagram");			
	}

	public static boolean findMissingLetters(String str) {

		boolean[] mark = new boolean[26];

		int index = 0;
		for (int i = 0; i < str.length(); i++) {
			if ('a' <= str.charAt(i) && str.charAt(i) <= 'z')
				index = str.charAt(i) - 'a';
			mark[index] = true;
		}
		for (int i = 0; i <= 25; i++)
			if (!mark[i])
				return (false);
		return (true);
	}

}
