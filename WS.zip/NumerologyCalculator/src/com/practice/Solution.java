package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the name:");
		String name = br.readLine().replaceAll(". ", "").toUpperCase();
		//String[] characterArray = name.toCharArray();
		int number=0;
		for(int i=0;i<name.length();i++)
		{
			char character = name.charAt(i);
			if(character == 'A' || character == 'I' || character == 'J' || character == 'Q' || character == 'Y')
			{
				number += 1;
			}
			else if(character == 'B' || character == 'K' || character == 'R')
			{
				number += 2;
			}
			else if(character == 'C' || character == 'G' || character == 'L' || character == 'S')
			{
				number += 3;
			}
			else if(character == 'D' || character == 'M' || character == 'T')
			{
				number += 4;
			}
			else if(character == 'E' || character == 'H' || character == 'N' || character == 'X')
			{
				number += 5;
			}
			else if(character == 'U' || character == 'V' || character == 'W')
			{
				number += 6;
			}
			else if(character == 'O' || character == 'Z')
			{
				number += 7;
			}
			else if(character == 'F' || character == 'P')
			{
				number += 8;
			}
		}
		System.out.println("Sum of the number: "+getSum(number));
	}

	private static int getSum(int number) {

		int sum = 0; 

		while (number != 0) 
		{ 
			sum = sum + number % 10; 
			number = number/10; 
		} 

		return sum; 
	}
}
