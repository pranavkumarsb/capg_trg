package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Solution {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the size of array set:");
		int size = Integer.parseInt(br.readLine().trim());
		System.out.println("Enter the array set:");
		List<List<Integer>> arraySet = new ArrayList<>();
		IntStream.range(0, size).forEach(i -> {
			try {
				arraySet.add(Stream.of(br.readLine().split(",")).map(Integer::parseInt).collect(Collectors.toList()));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		for(List<Integer> s: arraySet)
		{
			System.out.println(s);
		}
		System.out.println("Length of shortest array set: "+shortestArraySet(arraySet));

	}

	private static int shortestArraySet(List<List<Integer>> arraySet)
	{
		int firstSet,secondSet,shortestLength = 0;
		//Iterator<List<Integer>> iterator = arraySet.iterator();
		firstSet = arraySet.get(0).size();
		for(int j=1;j<arraySet.size();j++)
		{
			secondSet = arraySet.get(j).size();
			if(firstSet>secondSet)
			{
				firstSet=secondSet;
			}
		}
		shortestLength=firstSet;
		return shortestLength;
	}
}
