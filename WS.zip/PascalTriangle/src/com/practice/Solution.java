package com.practice;

import java.util.Scanner;

public class Solution {
	
	static int factorial(int num) {
		int factorial;

		for(factorial = 1; num > 1; num--){
			factorial *= num;
		}
		return factorial;
	    }
	    static int calculate(int n,int r) {
		return factorial(n) / ( factorial(n-r) * factorial(r) );
	    }
	    public static void main(String args[]){
	    	int rows, i, j;
	    	System.out.println("Enter number of rows:");
	    	Scanner scanner = new Scanner(System.in);
	    	rows = scanner.nextInt();
	    	int [][] triangle= new int[rows][rows];

	    	System.out.println("Pascal Triangle:");
	    	for(i = 0; i < rows; i++) {
	    		for(j = 0; j < rows-i; j++){
	    			System.out.print(" ");
	    		}
	    		for(j = 0; j <= i; j++){
	    			triangle[i][j] = calculate(i, j);
	    			System.out.print(" "+triangle[i][j]);
	    		}
	    		System.out.println();
	    	}

	    	System.out.println("Enter the co-ordinate of X & Y:");
	    	int xCoordinate = scanner.nextInt();
	    	int yCoordinate = scanner.nextInt();
	    	if(xCoordinate<rows && yCoordinate<rows)
	    	{
	    	System.out.println("Element in given co-ordinate: "+triangle[xCoordinate-1][yCoordinate-1]);
	    	}
	    	else
	    	{
	    		System.out.println("Coordinate doesn't exist");
	    	}
	    	scanner.close();
	    }
}
