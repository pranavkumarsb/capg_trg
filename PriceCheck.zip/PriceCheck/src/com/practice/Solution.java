package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Solution {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of products:");
		int productCount = Integer.parseInt(br.readLine().trim());
		List<String> product = new ArrayList<String>();
		System.out.println("Enter the products:");
		for(int i=0;i<productCount;i++)
		{
			product.add(br.readLine().trim());
		}
		System.out.println("Enter the size of product price:");
		int productPrice = Integer.parseInt(br.readLine().trim());
		List<String> priceList = new ArrayList<String>();
		System.out.println("Enter the product price:");
		for(int i=0;i<productPrice;i++)
		{
			priceList.add(br.readLine().trim());
		}
		System.out.println("Enter sold products size:");
		int productSold = Integer.parseInt(br.readLine().trim());
		List<String> productList = new ArrayList<String>();
		System.out.println("Enter the sold products:");
		for(int i=0;i<productSold;i++)
		{
			productList.add(br.readLine().trim());
		}
		System.out.println("Enter the size of sold product:");
		int soldPriceSize = Integer.parseInt(br.readLine().trim());
		List<String> soldPrice = new ArrayList<String>();
		System.out.println("Enter the sold price:");
		for(int i=0;i<soldPriceSize;i++)
		{
			soldPrice.add(br.readLine().trim());
		}
		System.out.println("Number of sale prices that were entered incorrectly are "+priceCheck(product, priceList, productList, soldPrice));
	}

	private static int priceCheck(List<String> product, List<String> priceList, List<String> productList,
			List<String> soldPrice) {
		int count=0;
		Map<String, String> currentMap = new HashMap<>();
		for(int i=0;i<product.size();i++)
		{
			currentMap.put(product.get(i), priceList.get(i));
		}

		Map<String, String> soldMap = new HashMap<>();
		for(int i=0;i<productList.size();i++)
		{
			soldMap.put(productList.get(i), soldPrice.get(i));
		}

		Iterator<Entry<String, String>> iterator = soldMap.entrySet().iterator();
		{
			while(iterator.hasNext()) {
				Map.Entry<String, String> mapElement = (Entry<String, String>) iterator.next();
				if(currentMap.containsKey(mapElement.getKey()))
				{
					if(!(currentMap.get(mapElement.getKey())).equalsIgnoreCase(mapElement.getValue()))
					{
						count++;
					}
					else {
						continue;
					}
				}
			}
		}
		return count;
		// TODO Auto-generated method stub

	}
}