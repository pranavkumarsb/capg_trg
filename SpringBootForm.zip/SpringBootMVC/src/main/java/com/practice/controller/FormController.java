package com.practice.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.practice.bean.UserBean;

@Controller
public class FormController {

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String validateLogin(@RequestParam("username") String userName,	@RequestParam("password")String userPwd, ModelMap map)
	{		
		if(userName.equals("pranav") &&
				userPwd.equals("pranav123")) {
			map.put("msg", "Welcome!  <b>" + 
					userName +"</b>");
			return "home";
		}else {
			map.put("msg","Sorry! Login Failed! Not Authorized User!");
			return "index";
		}	
	}

	@RequestMapping(value="/addUser", method=RequestMethod.GET)
	public String editRegister() {
		return "register";
	}

	@RequestMapping(value="/registerUser", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute("registerUser") UserBean userInfo,
			ModelMap model) {
		System.out.println(userInfo.getDateOfBirth());
		ModelAndView modelandview = new ModelAndView("registerUser");
		model.addAttribute("firstName",userInfo.getFirstName());
		model.addAttribute("lastName",userInfo.getLastName());
		model.addAttribute("address",userInfo.getAddress());
		model.addAttribute("city",userInfo.getCity());
		model.addAttribute("contactNumber",userInfo.getContactNumber());
		model.addAttribute("password",userInfo.getPassword());
		model.addAttribute("dateOfBirth", userInfo.getDateOfBirth());
		modelandview.setViewName("registersuccess");
		return modelandview;
	}
}
