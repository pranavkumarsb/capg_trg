function checkPassword(form) { 
	var password = form.password.value; 
	var confirmPassword = form.confirmPassword.value; 

	if (password == '') {
		alert ("\nPlease enter Password");
		return false;
	}

	else if (confirmPassword == '') {
		alert ("\nPlease enter confirm password"); 
		return false;
	}

	else (password != confirmPassword) { 
		alert ("\nPassword did not match: Please try again...") 
		return false; 
	}
	return true;
} 