function enable() {
document.getElementById("password").disabled = false;
}