package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Solution {

	private static int getNumberOfOptions(List<Integer> priceOfJeans, List<Integer> priceOfShoes,
			List<Integer> priceOfSkirts, List<Integer> priceOfTops, int budget) {
		// TODO Auto-generated method stub
		int count = 0;
		List<List<Integer>> matchedPostions = new ArrayList<List<Integer>>();
		matchedPostions.add(priceOfJeans);
		matchedPostions.add(priceOfShoes);
		matchedPostions.add(priceOfSkirts);
		matchedPostions.add(priceOfTops);
		Collections.sort(matchedPostions, new Comparator<List<Integer>>() {
			@Override
			public int compare(List<Integer> o1, List<Integer> o2) {
				return Integer.valueOf(o1.size()).compareTo(Integer.valueOf(o2.size()));
			}
		});

		for(int i=0;i<matchedPostions.get(0).size();i++) {
			for(int j=0;j<matchedPostions.get(1).size();j++) {
				for(int k=0;k<matchedPostions.get(2).size();k++) {
					for(int l=0;l<matchedPostions.get(3).size();l++) {
						if((matchedPostions.get(0).get(i) + matchedPostions.get(1).get(j) + matchedPostions.get(2).get(k) + matchedPostions.get(3).get(l)) <= budget) {
							count++;
						}
					} 
				}
			}
		}

		return count;
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the price count of Jeans:");
		int jeansPrice = Integer.parseInt(br.readLine().trim());
		List<Integer> priceOfJeans = new ArrayList<Integer>();
		System.out.println("Enter the prices of Jeans:");
		for (int i = 0; i < jeansPrice; i++) {
			priceOfJeans.add(new Integer(br.readLine().trim()).intValue());
		}

		System.out.println("Enter the price count of Shoes:");
		int shoesPrice = Integer.parseInt(br.readLine().trim());
		List<Integer> priceOfShoes = new ArrayList<Integer>();
		System.out.println("Enter the prices of Shoes:");
		for (int i = 0; i < shoesPrice; i++) {
			priceOfShoes.add(new Integer(br.readLine().trim()).intValue());
		}

		System.out.println("Enter the price count of Skirts:");
		int skirtsPrice = Integer.parseInt(br.readLine().trim());
		List<Integer> priceOfSkirts = new ArrayList<Integer>();
		System.out.println("Enter the prices of Skirts:");
		for (int i = 0; i < skirtsPrice; i++) {
			priceOfSkirts.add(new Integer(br.readLine().trim()).intValue());
		}

		System.out.println("Enter the price count of Tops:");
		int topsPrice = Integer.parseInt(br.readLine().trim());
		List<Integer> priceOfTops = new ArrayList<Integer>();
		System.out.println("Enter the prices of Tops:");
		for (int i = 0; i < topsPrice; i++) {
			priceOfTops.add(new Integer(br.readLine().trim()).intValue());
		}

		System.out.println("Enter the Budget:");
		int budget = Integer.parseInt(br.readLine().trim());

		System.out.println("Number of Ways to purchase: "
				+ getNumberOfOptions(priceOfJeans, priceOfShoes, priceOfSkirts, priceOfTops, budget));
	}
}
