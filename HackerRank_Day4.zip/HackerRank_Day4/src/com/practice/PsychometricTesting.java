package com.practice;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PsychometricTesting {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter range of scores:");
		int scoreRange = scan.nextInt();
		int[] scores = new int[scoreRange];
		//Integer.parseInt(br.readLine().trim());
		System.out.println("Enter scores:");
		for(int i=0;i<scoreRange;i++)
		{
			scores[i] = scan.nextInt();
		}
		System.out.println("Enter range of Lower Limit:");
		int lowerLimitRange = scan.nextInt();
		int[] lowerLimits = new int[lowerLimitRange];
		System.out.println("Enter Lower Limit(s):");
		for(int i=0;i<lowerLimitRange;i++) 
		{ 
			lowerLimits[i] = scan.nextInt();
		}
		System.out.println("Enter range of Upper Limit:");
		int upperLimitRange = scan.nextInt();
		int[] upperLimits = new int[upperLimitRange];
		System.out.println("Enter Upper Limit(s):");
		for(int	i=0;i<upperLimitRange;i++) 
		{ 
			upperLimits[i] = scan.nextInt();
		}
		System.out.println("Count of Scores in the given range:"+jobOffers(scores,lowerLimits,upperLimits));
		scan.close();
	}

	private static List<Integer> jobOffers(int[] scores, int[] lowerLimits, int[] upperLimits) {
		// TODO Auto-generated method stub
		List<Integer> result = new ArrayList<>();
		int count;
		for(int i=0,j=0;i<lowerLimits.length && j<upperLimits.length;i++,j++)
		{
			count = 0;
			for(int k=0; k < scores.length; k++)
			{
				if(scores[k]>=lowerLimits[i] && scores[k]<=upperLimits[j])
				{
					count++;
				}
				else
				{
					continue;
				}
			}
			result.add(count);
		}
		return result;
	}
}