package com.practice.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.practice.bean.LoginBean;
import com.practice.bean.UserBean;

@Controller
public class FormController {

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView getAllOrder(@ModelAttribute("login")  LoginBean login,
			ModelMap model) {
		ModelAndView modelandview = new ModelAndView("login");
		model.addAttribute("name",login.getUsername());
		modelandview.addAllObjects(model);
		modelandview.setViewName("home");
		return modelandview;
	}

	@RequestMapping(value="/addUser", method=RequestMethod.GET)
	public String editRegister() {
		return "register";
	}

	@RequestMapping(value="/registerUser", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute("registerUser") UserBean userInfo,
			ModelMap model) {
		ModelAndView modelandview = new ModelAndView("registerUser");
		model.addAttribute("name",userInfo.getName());
		model.addAttribute("email",userInfo.getEmail());
		model.addAttribute("password",userInfo.getPassword());
		model.addAttribute("gender",userInfo.getGender());
		model.addAttribute("profession",userInfo.getProfession());
		modelandview.setViewName("registersuccess");
		return modelandview;
	}
}
