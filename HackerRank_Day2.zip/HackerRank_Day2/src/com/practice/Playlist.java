package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Playlist {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		List<String> songList = new ArrayList<>(Arrays.asList("wheniseeyouagain", "borntorun", "nothingelsematters", "cecelia"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter current Song:");
		String currentSong = br.readLine();
		int currentIndex = songList.indexOf(currentSong);
		System.out.println("Enter next Song:");
		String nextSong = br.readLine();
		System.out.print("Minimum number of jumps to reach "+nextSong+" is "
				+ minJumps(songList, currentIndex, nextSong));
	}

	private static int minJumps(List<String> songList, int currentIndex, String nextSong) {
		// TODO Auto-generated method stub
		int moveForward = 0;
		int moveBackward = 0;
		for(int i=currentIndex;i<songList.size();)
		{
			if((songList.get(i)).equalsIgnoreCase(nextSong))
			{
				break;
			}
			if(i==songList.size()-1) {
				i=0;
			}
			else {
				i++;
			}
			moveForward++;
			
		}
		for(int i=currentIndex;i>=currentIndex;)
		{
					
			if((songList.get(i)).equalsIgnoreCase(nextSong))
			{
				break;
			}
			if(i==0) {
				i=songList.size()-1;
			}
			else {
				i--;
			}
			moveBackward++;	
		}
		if(moveForward>moveBackward)
			return moveBackward;
		else
			return moveForward;
	}

}
