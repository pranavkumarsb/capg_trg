package com.practice;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class FunWithAnagrams {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> a = Arrays.asList("poke", "pkoe", "okpe", "ekop");
        System.out.println(anagramCheck(a));
	}

	private static List<String> anagramCheck(List<String> anagramList) {
		// TODO Auto-generated method stub
		List<String> result = new LinkedList<String>();
        Set<String> setElement = new HashSet<String>();
       for (int i=0; i<anagramList.size(); i++) {
            String anagram = anagramList.get(i);
            String keyElement = elementSort(anagram);
            if (!setElement.contains(keyElement)) {
                result.add(anagram);
                setElement.add(keyElement);
            }

        }

        Collections.sort(result);

        return result;
	}

	private static String elementSort(String word) {
		// TODO Auto-generated method stub
		char[] chars = word.toCharArray();
        Arrays.sort(chars);
        return new String(chars);
	}

}