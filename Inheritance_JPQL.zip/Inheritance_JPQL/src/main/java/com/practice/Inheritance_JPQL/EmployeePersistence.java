package com.practice.Inheritance_JPQL;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EmployeePersistence {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employee_details");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		ActiveEmployee ae1 = new ActiveEmployee(101, "Rahman", 100000, 5);
		ActiveEmployee ae2 = new ActiveEmployee(102, "Rehana", 120000, 7);

		RetiredEmployee re1 = new RetiredEmployee(103, "Prakash", 50000);
		RetiredEmployee re2 = new RetiredEmployee(104, "Bob", 40000);

		em.persist(ae1);
		em.persist(ae2);

		em.persist(re1);
		em.persist(re2);

		em.getTransaction().commit();

		em.close();
		emf.close();

	}
}
