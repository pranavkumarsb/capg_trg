package com.hackerrank;

public class WagonR extends Car{

	private int mileage;
	
	public WagonR(int mileage) {
		this.mileage = mileage;
	}

	@Override
	String getMileage() {
		return mileage+" kmpl";
	}

}
