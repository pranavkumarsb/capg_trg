package com.hackerrank;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Result
{
    public static void main(String[] args) throws NumberFormatException, IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter Car code between [0,1,2]:");
    	int carCode = Integer.parseInt(br.readLine().trim());
    	System.out.println("Enter Mileage:");
        int mileage = Integer.parseInt(br.readLine().trim());
        
        if(carCode == 0){
            Car wagonR = new WagonR(mileage);
            wagonR.typeOfCar("WagonR");
        }
        
        if(carCode == 1){
            Car hondaCity = new HondaCity(mileage);
            hondaCity.typeOfCar("HondaCity");
        }
        
        if(carCode == 2){
            Car innovaCrysta = new InnovaCrysta(mileage);
            innovaCrysta.typeOfCar("InnovaCrysta");
        }
    }
}
