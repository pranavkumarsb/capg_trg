package com.hackerrank;

public class InnovaCrysta extends Car{

	private int mileage;

	public InnovaCrysta(int mileage) {
		this.mileage = mileage;
	}

	@Override
	String getMileage() {
		return mileage+" kmpl";
	}

}
