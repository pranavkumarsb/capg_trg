package com.hackerrank;

public abstract class Car {

	protected String isSedan;
    protected int seats;
	
	String getIsSedan(String name)
	{
		if(name.equals("WagonR"))
		{
			isSedan="not a Sedan";
		}
		if(name.equals("HondaCity"))
		{
			isSedan="a Sedan";
		}
		if(name.equals("InnovaCrysta"))
		{
			isSedan="Not a Sedan";
		}
		return isSedan;
	}
	
	int getSeats(String name)
	{
		if(name.equals("WagonR"))
		{
			seats=4;
		}
		if(name.equals("HondaCity"))
		{
			seats=4;
		}
		if(name.equals("InnovaCrysta"))
		{
			seats=6;
		}
		return seats;
	}

	abstract String getMileage();

	public void typeOfCar(String name) {

		System.out.println("A "+name+" is "+getIsSedan(name)+", is "+getSeats(name)+" Seater, and has a mileage of "+this.getMileage());
	}
}
