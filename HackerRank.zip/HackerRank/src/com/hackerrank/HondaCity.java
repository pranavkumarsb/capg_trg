package com.hackerrank;

public class HondaCity extends Car{

	private int mileage;

	public HondaCity(int mileage) {
		this.mileage = mileage;
	}

	@Override
	String getMileage() {
		return mileage+" kmpl";
	}

}
