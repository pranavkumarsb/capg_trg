package com.practice;

public class Engineer extends Employee{

	private int salary;
	private String grade;
	
	@Override
	public int getSalary() {
		// TODO Auto-generated method stub
		return salary;
	}

	@Override
	public void setSalary(int salary) {
		// TODO Auto-generated method stub
		this.salary = salary;
	}

	@Override
	public String getGrade() {
		// TODO Auto-generated method stub
		return grade;
	}

	@Override
	public void setGrade(String grade) {
		// TODO Auto-generated method stub
		this.grade = grade;
	}

}
