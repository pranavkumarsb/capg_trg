package com.practice;

public abstract class Employee {

	int salary;
	String grade;
	
	public abstract int getSalary();
	public abstract void setSalary(int salary);
	
	public abstract String getGrade();
	public abstract void setGrade(String grade);
	
	void label(String grade, int Salary) {
		System.out.println("Employee's data: ");
		System.out.println("Grade: "+grade);
		System.out.println("Salary: "+Salary);
	}
}
