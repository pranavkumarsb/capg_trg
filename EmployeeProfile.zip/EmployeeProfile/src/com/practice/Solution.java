package com.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Solution {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter nummber of inputs:");
		int inputCount = Integer.parseInt(br.readLine().trim());
		List<String> aList = new ArrayList<>();
		System.out.println("Enter the inputs:");
		for(int i=0;i<inputCount;i++)
		{
			aList.add(br.readLine().trim());
		}
		for(int i=0;i<inputCount;i++)
		{
			String[] type = aList.get(i).split(" ");
			switch(type[0].toUpperCase()) {
			case "ENGINEER":
				Engineer engineer = new Engineer();
				int engineerSalary = Integer.parseInt(type[2]);
				engineer.setGrade(type[1].trim());
				engineer.setSalary(engineerSalary);
				engineer.label(engineer.getGrade(), engineer.getSalary());
				break;
			case "MANAGER":
				Manager manager = new Manager();
				int managerSalary = Integer.parseInt(type[2]);
				manager.setGrade(type[1].trim());
				manager.setSalary(managerSalary);
				manager.label(manager.getGrade(), manager.getSalary());
				break;
			}
		}
	}
}
