package com.practice.bean;

//import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ADDRESS_TABLE")
@SequenceGenerator(name = "addseq",initialValue = 2000)
public class Address {
	
	@Id
	@Column(name = "address_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "addseq")
	private int addressId;
	@Column(name = "street_name")
	private String streetName;
	@Column(name = "city")
	private String city;
	//@ManyToOne(cascade = CascadeType.PERSIST)
	//@JoinColumn(name="employeeId_fk")
	//private Employee employee;

	public Address() {
		super();
	}

	public Address(int addressId, String streetName, String city) {
		super();
		this.addressId = addressId;
		this.streetName = streetName;
		this.city = city;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", streetName=" + streetName + ", city=" + city + "]";
	}
}
