package com.practice.controller;

import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.practice.bean.Employee;
import com.practice.service.IEmployeeService;

@SuppressWarnings({ "unchecked", "rawtypes" })
@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;

	@GetMapping("/getemployees")
	public ResponseEntity<List<Employee>> getAllEmployees(){
		List<Employee> employees= employeeService.getAllEmployees();

		if(employees==null|| employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employee available!",
					HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PostMapping("/employee")
	public ResponseEntity<Employee> createEmployee(
			@RequestBody Employee employee){
		Employee employeeData= employeeService.saveEmployee(employee);

		if(employeeData==null) {
			return new ResponseEntity("Sorry! Insertion Failed!", HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<Employee>(employeeData, HttpStatus.OK);

	}

	@GetMapping("/getemployee/{employeeId}")
	public ResponseEntity<Employee> findEmployee(
			@PathVariable("employeeId")Integer employeeId){
		Employee employee= employeeService.findEmployee(employeeId);

		if(employee==null) {
			return new ResponseEntity("Sorry! Employee ID does not exist!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}

	@PutMapping("/putemployee/{employeeId}")
	public ResponseEntity<Employee> putUpdateEmployee(
			@PathVariable(value = "employeeId") Integer employeeId, @RequestBody Employee employeeDetails) {

		Employee employee = employeeService.findEmployee(employeeId);

		if(employee==null) {
			return new ResponseEntity("Sorry! Employee ID does not exist!", HttpStatus.NOT_FOUND);
		}

		employee.setFirstName(employeeDetails.getFirstName());
		employee.setLastname(employeeDetails.getLastname());
		employee.setSalary(employeeDetails.getSalary());
		Employee updatedEmployee = employeeService.saveEmployee(employeeDetails);

		return new ResponseEntity<Employee>(updatedEmployee, HttpStatus.OK);
	}

	@PutMapping("/patchemployee/{employeeId}")
	public ResponseEntity<Employee> updateEmployee(
			@PathVariable(value = "employeeId") Integer employeeId, @RequestBody Employee employeeDetails) {

		Employee employee = employeeService.findEmployee(employeeId);

		if(employee==null) {
			return new ResponseEntity("Sorry! Employee ID does not exist!", HttpStatus.NOT_FOUND);
		}

		employee.setSalary(employeeDetails.getSalary());
		Employee updatedEmployee = employeeService.saveEmployee(employeeDetails);

		return new ResponseEntity<Employee>(updatedEmployee, HttpStatus.OK);
	}

	@DeleteMapping("/deleteemployee/{employeeId}")
	public ResponseEntity<Employee> deleteEmployee(
			@PathVariable("employeeId")Integer employeeId){

		Employee employee= employeeService.findEmployee(employeeId);
		employeeService.deleteEmployee(employeeId);

		if(employee==null) {
			return new ResponseEntity("Sorry! Employee ID does not exist!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}

	@GetMapping("/salarysum")
	public String getSumOfSalary() {
		return JSONObject.toString("sumOfSalary", employeeService.getSumOfSalary());
	}

	@GetMapping("/minsalary")
	public String getMinOfSalary() {
		return JSONObject.toString("minimumSalary", employeeService.getMinOfSalary());
	}

	@GetMapping("/maxsalary")
	public String getMaxOfSalary() {
		return JSONObject.toString("maximumSalary", employeeService.getMaxOfSalary());
	}

	@GetMapping("/sortbyname")
	public List<Employee> findByOrderByFirstNameAsc() {
		return employeeService.findByOrderByFirstNameAsc();
	}

	/*@GetMapping("/getlike/{likeString}")
	public ResponseEntity<List<Employee>> findAllLikeString(@PathVariable("likeString")String likeString){
		List<Employee> employees= employeeService.findAllLikeString(likeString);
		if(employees==null|| employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employee available!",
					HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}*/
}
