package com.practice.service;

import java.util.List;

import com.practice.bean.Employee;

public interface IEmployeeService {

	Employee saveEmployee(Employee employee);

	List<Employee> getAllEmployees();

	Employee findEmployee(Integer employeeId);

	void deleteEmployee(Integer employeeId);
	
	Double getSumOfSalary();

	Double getMinOfSalary();

	Double getMaxOfSalary();

	List<Employee> findByOrderByFirstNameAsc();
	
	//List<Employee> findAllLikeString(String likeString);
}
