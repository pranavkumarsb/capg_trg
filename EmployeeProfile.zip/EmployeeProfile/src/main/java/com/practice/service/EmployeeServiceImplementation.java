package com.practice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practice.bean.Employee;
import com.practice.dao.IEmployeeDBDao;

@Service("employeeService")
public class EmployeeServiceImplementation implements IEmployeeService{

	@Autowired
	private IEmployeeDBDao employeeDBDao;
	
	@Override
	public List<Employee> getAllEmployees() {
		
		return employeeDBDao.findAll();
	}
	
	@Override
	public Employee saveEmployee(Employee employee) {
		return employeeDBDao.save(employee);
	}

	@Override
	public Employee findEmployee(Integer employeeId) {
		return employeeDBDao.getOne(employeeId);
	}

	@Override
	public void deleteEmployee(Integer employeeId) {
		employeeDBDao.deleteById(employeeId);
	}
	
	@Override
	public Double getSumOfSalary()
	{
		return employeeDBDao.getSumOfSalary();	
	}

	@Override
	public Double getMinOfSalary() {
		return employeeDBDao.getMinOfSalary();
	}
	
	@Override
	public Double getMaxOfSalary() {
		return employeeDBDao.getMaxOfSalary();
	}

	@Override
	public List<Employee> findByOrderByFirstNameAsc() {
		return employeeDBDao.findByOrderByFirstNameAsc();
	}

	/*@Override
	public List<Employee> findAllLikeString(String likeString) {
		return employeeDBDao.findAllLikeString(likeString);
	}*/

}
