package com.practice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.practice.bean.Employee;

@Repository("employeeDBDao")
public interface IEmployeeDBDao extends JpaRepository<Employee, Integer>{

	@Query("SELECT sum(e.salary) from Employee e")
	public Double getSumOfSalary();

	@Query("SELECT min(e.salary) from Employee e")
	public Double getMinOfSalary();

	@Query("SELECT max(e.salary) from Employee e")
	public Double getMaxOfSalary();

	List<Employee> findByOrderByFirstNameAsc();

	/*@Query(
			value = "SELECT e FROM Employee e WHERE e.firstName LIKE ?1%", 
			nativeQuery = true)
	public List<Employee> findAllLikeString(String likeString);*/
}
