package com.practice;

import com.practice.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyJavaConfig {

	@Bean
	public Employee getEmployeeBean() {
		Employee employee=new Employee();
		employee.setEmployeeId(198);
		employee.setFirstName("Pranav");
		employee.setLastName("Kumar");
		employee.setSalary(23000);
		return employee;
	}
	
	@Bean 
	 public TokenMachine tokenMachine(){
	  return new TokenMachine(){

	   @Override
	   public Token generateToken() {
	    return new Token();
	   }
	   
	  };
	 }
}
