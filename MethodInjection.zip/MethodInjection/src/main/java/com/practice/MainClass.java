package com.practice;

import com.practice.Employee;
import com.practice.MyJavaConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context=
				new AnnotationConfigApplicationContext(MyJavaConfig.class);
	
	Employee employee= context.getBean(Employee.class);
	System.out.println(employee);
	
	TokenMachine machine= context.getBean(TokenMachine.class);
	System.out.println(machine);
	machine.findToken();
	
	TokenMachine machine1= context.getBean(TokenMachine.class);
	System.out.println(machine1);
	machine.findToken();
	
	TokenMachine machine2= context.getBean(TokenMachine.class);
	System.out.println(machine2);
	machine.findToken();
	
	context.close();
	}

}
