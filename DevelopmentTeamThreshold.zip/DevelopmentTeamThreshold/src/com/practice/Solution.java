package com.practice;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Solution {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//BufferedWriter bw = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));
		int rows = Integer.parseInt(br.readLine().trim());
		//int columns = 2;
		List<List<Integer>> teams = new ArrayList<>();
		IntStream.range(0, rows).forEach(i -> {
			try {
				teams.add(Stream.of(br.readLine().replaceAll("\\s+$", "").split(" ")).map(Integer::parseInt).collect(Collectors.toList()));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw new RuntimeException(e);
			}
		});
		int percentage = Integer.parseInt(br.readLine().trim());
		/*
		 * for(List<Integer> s : teams) { System.out.println(s); }
		 */
		int result = Solution.hireSeniorDevs(teams,percentage);
		System.out.println("Number of Employees to hire "+result);
		//bw.write(String.valueOf(result));
	}

	private static int hireSeniorDevs(List<List<Integer>> teams, int percentage) {
		// TODO Auto-generated method stub
		int count = 0,result = 0;
		List<Integer> al = new ArrayList<Integer>();
		for(int i=0;i<teams.size();i++)
		{
			al = teams.get(i);
			int dividend = al.get(0);
			int divisor =  al.get(1);
			System.out.println(dividend);
			System.out.println(divisor);
			int counter = calculatePercentage(dividend,divisor,percentage);
			if(counter>dividend)
			{
				count = counter-dividend;
			}
			result += count;
		}
		return result;
	}

	private static int calculatePercentage(int dividend, int divisor, int percentage) {

		Double thresholdPercentage = (double) ((dividend*100)/divisor);
		while(!(thresholdPercentage>=percentage))
		{
			dividend++;
			divisor++;
			thresholdPercentage = (double) ((dividend*100)/divisor);
		}
		return dividend;
		// TODO Auto-generated method stub

	}

}
